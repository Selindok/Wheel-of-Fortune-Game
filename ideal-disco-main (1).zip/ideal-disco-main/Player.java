import java.util.ArrayList;

public class Player extends WheelClass {
    private String playerName;
    private int playerTurns = 10;
    private int totalAnsweredQuestions;
    private int totalEasyQuest;
    private int totalMedQuest;
    private int totalHardQuest;
    private int totalBraveQuest;
    private int totalPlayedTurns;
    private int playerPoints;
    private static final int brave = 15;
    private static final int easy = 5;
    private static final int medium = 10;
    private static final int hard = 20;
    private ArrayList<Integer> recordedRolls = new ArrayList<>();
    /*
    0 = easy
    1 = medium
    2 = hard
    3 = brave
     */

    public int getTotalBraveQuest() {
        return totalBraveQuest;
    }

    public int getTotalAnsweredQuestions() {
        return totalAnsweredQuestions;
    }

    public int getTotalEasyQuest() {
        return totalEasyQuest;
    }

    public int getTotalHardQuest() {
        return totalHardQuest;
    }

    public int getTotalMedQuest() {
        return totalMedQuest;
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getPlayerTurns() {
        return playerTurns;
    }

    public int getTotalPlayedTurns() {
        return totalPlayedTurns;
    }

    public void setPlayerPass(int playerPass) {
        this.playerTurns = playerPass;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public void setPlayerTurns(int playerTurns) {
        this.playerTurns = playerTurns;
    }

    public void setTotalAnsweredQuestions(int totalAnsweredQuestions) {
        this.totalAnsweredQuestions = totalAnsweredQuestions;
    }

    public void setTotalEasyQuest(int totalEasyQuest) {
        this.totalEasyQuest = totalEasyQuest;
    }

    public void setTotalHardQuest(int totalHardQuest) {
        this.totalHardQuest = totalHardQuest;
    }

    public void setTotalMedQuest(int totalMedQuest) {
        this.totalMedQuest = totalMedQuest;
    }

    public void setTotalPlayedTurns(int totalPlayedTurns) {
        this.totalPlayedTurns = totalPlayedTurns;
    }

    public void setTotalBraveQuest(int totalBraveQuest) {
        this.totalBraveQuest = totalBraveQuest;
    }

    public void addPointsandTurns() {
        if (wheel.equals("dare")) {
            playerPoints = +brave;
            playerTurns--;
        } else {
            switch (quest) {
                case 0: {
                    playerPoints = +easy;
                    playerTurns--;
                    break;
                }
                case 1: {
                    playerPoints = +medium;
                    playerTurns--;
                    break;
                }
                default: {
                    System.out.println("You should not be reading this !");
                    break;
                }
            }
        }

    }

    public int questionIndexFinder(String question) {
        int index = 0;
        for (int i = 0; i < hardWheel.size(); i++) {
            if (question.equals(hardWheel.get(i)))
                index = i;
            else
                continue;
        }
        return index;
    }

    public int answerChecker(String answer, String question) {
        int index = questionIndexFinder(question);
        int status = 0;

        for (int i = 0; i < hardWheelAnswer.size(); i++) {
            if (answer.equals(hardWheelAnswer.get(i))) {
                playerPoints = +hard;
                playerTurns--;
                status = 1;
            }
        }
        return status;
    }

    public void turnRemoval(){
        playerTurns--;
    }

    public void rollRecorder(){
        if (totalPlayedTurns != 0){

        }
    }


    //easy answered -> -1 turns
    //medium answered -> -1+1 = 0 turns
    //hard answered -> -1+2 = 1 turns
    //brave answered -> -1+2 = 1 turns
    //If a question is answered wrong or passed without an answer, the player will lose points depending on the level of the question

    //easy = 5 points
    //medium = 10 points
    //hard = 20 points
    //brave = 15 points
    //TOTAL POINTS 700
    //EASY TOTAL 100
    //MEDIUM TOTAL 150
    //HARD TOTAL 300
    //BRAVE TOTAL 150
    //brave is advantageous to medium because you can get a free turn

}
